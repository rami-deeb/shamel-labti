
// Example: Confirmation on form submission
document.querySelector('form').addEventListener('submit', function(e) {
    alert('تم إرسال رسالتك بنجاح!');
});
